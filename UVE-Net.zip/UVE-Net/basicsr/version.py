# GENERATED VERSION FILE
# TIME: Wed Oct  4 17:21:54 2023
__version__ = '1.3.3.10'
__gitsha__ = '1.3.3.10'
version_info = (1, 3, 3, 10)
